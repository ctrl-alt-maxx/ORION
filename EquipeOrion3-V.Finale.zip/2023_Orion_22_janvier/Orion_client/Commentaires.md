#Commentaires code
##Modèle
* Joueur.flotte = ensemble des vaisseaux du joueur : dictionnaire possédant deux dictionnaires représentant les vaisseaux cargos et les vaisseaux d'attaque. **TODO** : il faut y ajouter un troisième dictionnaire contenant les vaisseaux éclaireurs